-- VM-owned metadata receipt; inspect the shared parser without exposing binary section bytes.
function main(sdk, filename, output)
    import("core.base.json")
    local facts = import("wasm_module", {rootdir = path.join(sdk, "tools/xmake"), anonymous = true})
        .inspect(assert(io.readfile(filename, {encoding = "binary"})))
    local imports, exports = {}, {}
    for _, row in ipairs(facts.imports) do
        table.insert(imports, {module = row.module, name = row.name, kind = row.kind,
            signature = row.signature, memory = row.memory})
    end
    for _, row in ipairs(facts.exports) do
        table.insert(exports, {name = row.name, kind = row.kind, signature = row.signature})
    end
    json.savefile(output, {memories = facts.memories, imported_memories = facts.imported_memories,
        imported_tables = facts.imported_tables, imports = imports, exports = exports,
        dynamic_linking = facts.dynamic_linking})
end
