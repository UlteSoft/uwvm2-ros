"""Read-only compiler/provider gates, shared by both interruption cases and compile."""
from pathlib import Path
import gzip,json
from common import need,sha

def verify_inputs():
    packet=Path('/packet');base=Path('/base-sdk')
    binary=json.loads((packet/'xmake-binary.json').read_text());program=Path('/tool-bin/xmake')
    need(program.is_file() and program.stat().st_size==binary['bytes'] and sha(program)==binary['sha256'], 'exact Xmake binary unavailable')
    source_rows=json.loads(gzip.decompress((packet/'xmake-program-inputs.json.gz').read_bytes()))
    for row in source_rows:
        relative=Path(row['path']);need(not relative.is_absolute() and '..' not in relative.parts,'unsafe Xmake program path')
        path=Path('/tool-program')/relative
        need(path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'], 'Xmake program file unavailable/changed: '+row['path'])
    assets=json.loads(gzip.decompress((packet/'compile-assets.json.gz').read_bytes()))
    selected=next(t for t in json.loads((packet/'sdk-inputs/share/wasm/toolchains.json').read_text())['targets'] if t['triple']=='wasm32-wasip1' and t['profile']=='noeh')
    for key in ('sysroot','include_dir','lib_dir','resource_dir'):
        need((base/selected[key]).is_dir(),'declared exact target directory absent: '+selected[key])
    need(any(r['path'].startswith(selected['include_dir']+'/') for r in assets),'target headers missing from closed input inventory')
    for row in assets:
        relative=Path(row['path']);need(not relative.is_absolute() and '..' not in relative.parts,'unsafe compiler input path')
        path=base/relative
        need(path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'], 'compiler input unavailable/changed: '+row['path'])
    mounts={line.split()[4]:line.split()[5].split(',') for line in Path('/proc/self/mountinfo').read_text().splitlines()}
    need(all('ro' in mounts.get(name,[]) for name in ('/base-sdk','/tool-bin','/tool-program')),'compiler/tool inputs are not read-only mounts')
    return {'immutable_files':len(assets),'immutable_bytes':sum(r['bytes'] for r in assets),
        'xmake_program_files':len(source_rows),'xmake_binary_sha256':binary['sha256'],
        'llvm_archive_sha256':'8e97c5e26755459965d86361f970c9b7d6d2e7c44e953fc0faeb82621b157522',
        'compiler_executed_by_this_gate':False}
