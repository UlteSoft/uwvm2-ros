"""One closed Xmake C build and Wasm metadata inspection; never run a VM/robot."""
from pathlib import Path
import argparse,gzip,json,os,shutil,subprocess,time,traceback
from common import guard,need,sha,save

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--nonce',required=True);args=parser.parse_args()
    context=json.loads(Path('/context/context.json').read_text())
    need(args.nonce==context['nonce'] and context['mode']=='compile-portable','closed compiler nonce/mode differs')
    admission=guard()
    root=Path('/work/compile');root.mkdir();sdk=root/'sdk';sdk.mkdir()
    raw=root/'raw';raw.mkdir();artifacts=root/'artifacts';artifacts.mkdir()
    report={'status':'FAIL_OR_BLOCKED','compiler_commands':[],'actual_admission':admission,
        'vm_executed':False,'native_ros_executed':False,'official_simulator_executed':False,
        'host_portable_abi_implemented':False,'performance_measured':False}
    env=dict(os.environ,HOME=str(root/'home'),XMAKE_GLOBALDIR=str(root/'xmake-global'),XMAKE_PROGRAM_DIR='/tool-program',
        XMAKE_ROOT='y',XMAKE_STATS='false',XDG_CACHE_HOME=str(root/'cache'),TMPDIR=str(root/'tmp'),
        UWVM_ROS_SDK_ROOT=str(sdk),PATH='/tool-bin:/usr/bin:/bin',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1')
    for key in ('HOME','TMPDIR','XMAKE_GLOBALDIR','XDG_CACHE_HOME'):Path(env[key]).mkdir()
    deadline=time.monotonic()+480
    def command(name,argv,cwd):
        guard()
        remaining=deadline-time.monotonic();need(remaining>0,'finite compiler stage exhausted')
        try:r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=min(300,remaining));code=r.returncode;out=r.stdout;err=r.stderr
        except subprocess.TimeoutExpired as error:code=124;out=error.stdout or b'';err=error.stderr or b''
        need(len(out)+len(err)<=32*1024*1024,'finite compiler raw-log bound')
        (raw/(name+'.stdout')).write_bytes(out);(raw/(name+'.stderr')).write_bytes(err)
        report['compiler_commands'].append({'name':name,'argv':argv,'cwd':str(cwd),'exit_code':code,
            'stdout_sha256':sha(raw/(name+'.stdout')),'stderr_sha256':sha(raw/(name+'.stderr'))})
        save(root/'result.json',report);need(code==0,'actual command failed: '+name)
    try:
        for row in json.loads(Path('/packet/sdk-inputs.json').read_text()):
            source=Path('/packet/sdk-inputs')/row['path'];need(sha(source)==row['sha256'],'source changed before stage')
            target=sdk/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
        for row in json.loads(gzip.decompress(Path('/packet/compile-assets.json.gz').read_bytes())):
            target=sdk/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
            need(not target.exists(),'source/input overlap');target.symlink_to(Path('/base-sdk')/row['path'])
        project=sdk/'example/platform/ros/portable/v0_1_0/joint_step'
        command('configure',['/tool-bin/xmake','f','-y','-c','-a','wasm32'],project)
        command('build',['/tool-bin/xmake','-vD','-j2'],project)
        products=[p for p in (project/'build').rglob('*.wasm') if p.is_file()]
        need(len(products)==1,'one actual Wasm product required')
        product=products[0];shutil.copy2(product,artifacts/'joint-step.wasm')
        metadata=raw/'wasm-structure.json'
        command('inspect',['/tool-bin/xmake','l','/packet/inspect_artifacts.lua',str(sdk),str(product),str(metadata)],project)
        module=json.loads(metadata.read_text());memories=module['memories']+[r['memory'] for r in module['imports'] if r.get('memory')]
        need(len(memories)==1 and memories[0]['address_bits']==32 and not memories[0]['shared'],'actual canonical memory differs')
        imports=[r for r in module['imports'] if r.get('module')=='uwvm_portable_robot_v1']
        abi=json.loads((sdk/'share/platform/ros/portable/v0.1.0/abi.json').read_text())
        need({r['name'] for r in imports}=={r['name'] for r in abi['functions']},'actual portable imports differ')
        types={'i32':127,'i64':126}
        expected={r['name']:{'parameters':[types[p['type']] for p in r['params']],
            'results':[types[t] for t in r['results']]} for r in abi['functions']}
        need(all(r.get('kind')==0 and r.get('signature')==expected[r['name']] for r in imports),'actual portable scalar signatures differ')
        need(all(r.get('module') in ('uwvm_portable_robot_v1','wasi_snapshot_preview1') for r in module['imports']),'unexpected platform-specific import')
        need(any(r['name']=='_start' for r in module['exports']),'canonical command startup absent')
        # Retain actual compilation intermediates as artifacts, not the reproducible compiler cache.
        for p in project.rglob('*.o'):
            if p.is_file():
                target=artifacts/'objects'/p.relative_to(project);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
        report.update(status='PASS_COMPILED_WASM_STRUCTURE_ONLY',wasm_sha256=sha(artifacts/'joint-step.wasm'),
            wasm_bytes=(artifacts/'joint-step.wasm').stat().st_size,portable_imports=imports,
            source_manifest_sha256=sha(Path('/packet/packet-manifest.json')),
            llvm_manifest_sha256=sha(sdk/'share/toolchains/host/linux-x86_64/llvm23.json'),
            sdk_input_manifest_sha256=sha(Path('/packet/sdk-inputs.json')),
            final_actual_admission=guard(),qualification='One compiler/structural fixture only; all VM and simulation acceptance NOT_RUN')
    except BaseException as error:
        report.update(error=repr(error),traceback=traceback.format_exc())
    finally:
        save(root/'result.json',report)
    need(report['status']=='PASS_COMPILED_WASM_STRUCTURE_ONLY','compiler stage failed; retain original output')

if __name__=='__main__':main()
