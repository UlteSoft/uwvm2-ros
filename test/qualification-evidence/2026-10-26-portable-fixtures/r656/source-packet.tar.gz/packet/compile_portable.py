"""Two fixed public C/WASI builds; no VM, ROS node, or simulator execution."""
from pathlib import Path
import argparse,gzip,json,os,shutil,subprocess,time,traceback
from common import guard,need,sha,save

JOINT_SHA='c0d886e864243938999e4adf4c0f4ce6fb3c2c001723b855cd8b203bfafe2043'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--nonce',required=True);a=parser.parse_args()
    context=json.loads(Path('/context/context.json').read_text())
    need(a.nonce==context['nonce'] and context['mode']=='compile-portable','closed batch nonce/mode differs')
    admission=guard();root=Path('/work/compile');root.mkdir();sdk=root/'sdk';sdk.mkdir();raw=root/'raw';raw.mkdir();artifacts=root/'artifacts';artifacts.mkdir()
    report={'status':'FAIL_OR_BLOCKED','compiler_commands':[],'artifacts':[],'actual_admission':admission,
        'vm_executed':False,'native_ros_executed':False,'official_simulator_executed':False,'performance_measured':False}
    env=dict(os.environ,HOME=str(root/'home'),XMAKE_GLOBALDIR=str(root/'xmake-global'),XMAKE_PROGRAM_DIR='/tool-program',
        XMAKE_ROOT='y',XMAKE_STATS='false',XDG_CACHE_HOME=str(root/'cache'),TMPDIR=str(root/'tmp'),UWVM_ROS_SDK_ROOT=str(sdk),
        PATH='/tool-bin:/usr/bin:/bin',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1')
    for key in ('HOME','TMPDIR','XMAKE_GLOBALDIR','XDG_CACHE_HOME'):Path(env[key]).mkdir()
    deadline=time.monotonic()+480
    def command(name,argv,cwd):
        guard();remaining=deadline-time.monotonic();need(remaining>0,'bounded compiler deadline')
        try:r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=min(240,remaining));code=r.returncode;out=r.stdout;err=r.stderr
        except subprocess.TimeoutExpired as e:code=124;out=e.stdout or b'';err=e.stderr or b''
        need(len(out)+len(err)<=8*1024**2,'bounded per-command raw output')
        (raw/(name+'.stdout')).write_bytes(out);(raw/(name+'.stderr')).write_bytes(err)
        report['compiler_commands'].append({'name':name,'argv':argv,'cwd':str(cwd),'exit_code':code,
            'stdout_sha256':sha(raw/(name+'.stdout')),'stderr_sha256':sha(raw/(name+'.stderr'))})
        save(root/'result.json',report);need(code==0,'actual command failed: '+name)
    try:
        for row in json.loads(Path('/packet/sdk-inputs.json').read_text()):
            source=Path('/packet/sdk-inputs')/row['path'];need(sha(source)==row['sha256'],'exact staged source changed')
            target=sdk/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
        for row in json.loads(gzip.decompress(Path('/packet/compile-assets.json.gz').read_bytes())):
            target=sdk/row['path'];target.parent.mkdir(parents=True,exist_ok=True);need(not target.exists(),'source/asset overlap');target.symlink_to(Path('/base-sdk')/row['path'])
        need(sha(sdk/'lib/platform/ros/portable/v0.1.0/joint-step.wasm')==JOINT_SHA,'frozen joint artifact changed')
        recipe=json.loads((sdk/'share/platform/ros/portable/v0.3.0/algorithms.json').read_text())
        need([x['id'] for x in recipe['algorithms']]==['planar-goal-v0.3.0','sensor-digest-v0.3.0'],'closed two-algorithm batch differs')
        abi=json.loads((sdk/'share/platform/ros/portable/v0.1.0/abi.json').read_text());types={'i32':127,'i64':126}
        signatures={x['name']:{'parameters':[types[p['type']] for p in x['params']],'results':[types[t] for t in x['results']]} for x in abi['functions']}
        for item in recipe['algorithms']:
            ident=item['id'];project=sdk/item['project'];need(project.is_relative_to(sdk/'example/platform/ros/portable/v0_3_0'),'unexpected project')
            for source in item['source_files']:need(sha(sdk/source['path'])==source['sha256'],'algorithm source differs')
            command(ident+'-configure',['/tool-bin/xmake','f','-y','-c','-a','wasm32'],project)
            command(ident+'-build',['/tool-bin/xmake','-vD','-j2'],project)
            products=[f for f in (project/'build').rglob('*.wasm') if f.is_file()];need(len(products)==1,'one actual product per algorithm required')
            product=products[0];saved=artifacts/(ident+'.wasm');shutil.copy2(product,saved);metadata=raw/(ident+'-structure.json')
            command(ident+'-inspect',['/tool-bin/xmake','l','/packet/inspect_artifacts.lua',str(sdk),str(product),str(metadata)],project)
            module=json.loads(metadata.read_text());memories=module['memories']+[x['memory'] for x in module['imports'] if x.get('memory')]
            need(len(memories)==1 and memories[0]['address_bits']==32 and not memories[0]['shared'] and memories[0]['maximum']==1024,'one bounded unshared Wasm32 memory required')
            imports=[x for x in module['imports'] if x['module']=='uwvm_portable_robot_v1'];required=set(item['required_imports'])
            need(len(imports)==len(required) and {x['name'] for x in imports}==required,'capability-specific exact import set differs')
            need(all(x['kind']==0 and x['signature']==signatures[x['name']] for x in imports),'exact scalar import signatures differ')
            need(all(x['module'] in ('uwvm_portable_robot_v1','wasi_snapshot_preview1') for x in module['imports']),'unexpected module import')
            need(any(x['name']=='_start' and x.get('signature')=={'parameters':[],'results':[]} for x in module['exports']),'canonical command startup differs')
            report['artifacts'].append({'id':ident,'capability':item['capability'],'path':str(saved),'bytes':saved.stat().st_size,'sha256':sha(saved),
                'metadata_sha256':sha(metadata),'portable_imports':imports,'memories':memories,'source_files':item['source_files']})
            save(root/'result.json',report)
        need(sha(sdk/'lib/platform/ros/portable/v0.1.0/joint-step.wasm')==JOINT_SHA,'joint artifact changed during batch')
        report.update(status='PASS_COMPILED_WASM_STRUCTURES_ONLY',joint_sha256_unchanged=JOINT_SHA,
            source_manifest_sha256=sha(Path('/packet/packet-manifest.json')),sdk_input_manifest_sha256=sha(Path('/packet/sdk-inputs.json')),
            llvm_manifest_sha256=sha(sdk/'share/toolchains/host/linux-x86_64/llvm23.json'),final_actual_admission=guard(),
            qualification='Two public compiler/structure results only; VM/nativeROS/official simulator/QEMU/performance NOT_RUN')
    except BaseException as e:report.update(error=repr(e),traceback=traceback.format_exc())
    finally:save(root/'result.json',report)
    need(report['status']=='PASS_COMPILED_WASM_STRUCTURES_ONLY','actual batch failed; preserve all original results')

if __name__=='__main__':main()
