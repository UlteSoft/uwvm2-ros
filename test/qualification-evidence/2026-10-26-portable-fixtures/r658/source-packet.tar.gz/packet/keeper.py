"""One proof-only nonce-owned batch controller; guardian inherits its canonical flock FD."""
from __future__ import annotations
import argparse
import fcntl
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import time
from common import (control_command,signal_owned,MIB,GIB,WORK_CAP,CONTROL_CAP,ROOT_RESERVE,WORK_RESERVE,
                    linux,need,sha,save,birth,alive,device_key,packet_verify,
                    host_lease_proof,original_parent,inspect,exact_owned,context_load,measured_bytes,log_file_limit,rpc)

STOP=False


def stop_signal(_number,_frame):
    global STOP
    STOP=True


def cleanup_checkpoint(root,report):
    try:save(root/'keeper.json',report)
    except OSError as error:report.update(passed=False,receipt_error=repr(error))


def emergency_retire(context,root,report):
    """Guardian loss never releases the keeper's surviving lease over writers.

    Unknown create completion stays quarantined. With a recorded exact full ID,
    retire that namespace and its birth-checked clients using the same policy.
    This path always leaves the product result failed, even after safe cleanup.
    """
    inits=[];clients={};last_error=None
    while True:
        try:
            owned_path=root/'owned-container.json'
            need(owned_path.exists(),'guardian died before a conclusive owned-ID receipt; lease remains quarantined')
            owned=json.loads(owned_path.read_text())
            need(owned['nonce']==context['nonce'],'owned receipt nonce differs')
            cid=owned['container_id'];need(len(cid)==64 and all(c in '0123456789abcdef' for c in cid),'owned full ID missing')
            if owned.get('init') and owned['init'] not in inits:inits.append(owned['init'])
            row=inspect(cid,absent=True)
            if row is not None:
                exact_owned(row,context)
                if row['State']['Running']:
                    pid=row['State']['Pid']
                    current={'pid':pid,'birth':birth(pid),'cgroup':Path('/proc',str(pid),'cgroup').read_text().strip()}
                    if current not in inits:
                        need(len(inits)<128,'owned restart history exceeds bounded emergency evidence')
                        inits.append(current)
                    rpc(['docker','kill','--signal','KILL',cid],timeout=30)
                row=exact_owned(inspect(cid),context)
                need(not row['State']['Running'],'owned namespace remains running')
                rpc(['docker','rm',cid],timeout=30)
            need(inspect(cid,absent=True) is None,'owned namespace remains after emergency removal')
            for init in inits:
                need(not alive(init['pid'],init['birth']),'owned init birth remains live')
                need(init['cgroup'].startswith('0::') and '\n' not in init['cgroup'],'unified owned group proof missing')
                group=Path('/sys/fs/cgroup')/init['cgroup'][3:].lstrip('/')
                if group.exists():need(not (group/'cgroup.procs').read_text().split(),'owned cgroup still has writers')
            for path in Path('/proc').iterdir():
                if not path.name.isdecimal():continue
                try:
                    argv=(path/'cmdline').read_bytes().split(b'\0')
                    if argv and Path(os.fsdecode(argv[0])).name=='docker' and b'exec' in argv and cid.encode() in argv:
                        pid=int(path.name);need(len(clients)<256 or pid in clients,'owned client evidence ceiling reached')
                        clients[pid]={'pid':pid,'birth':birth(pid)}
                except (FileNotFoundError,ProcessLookupError,PermissionError):pass
            for client in clients.values():
                if alive(client['pid'],client['birth']):
                    try:
                        argv=Path('/proc',str(client['pid']),'cmdline').read_bytes().split(b'\0')
                        need(argv and Path(os.fsdecode(argv[0])).name=='docker' and b'exec' in argv and cid.encode() in argv,
                             'recorded emergency client no longer names this exact owned ID')
                        if alive(client['pid'],client['birth']):signal_owned(client['pid'],client['birth'],signal.SIGKILL)
                    except (FileNotFoundError,ProcessLookupError):pass
            need(not any(alive(row['pid'],row['birth']) for row in clients.values()),'owned Docker clients still retiring')
            after=original_parent(context)
            return {'status':'RETIRED_AFTER_GUARDIAN_LOSS','retired':True,'container_id':cid,
                    'retired_ns':time.monotonic_ns(),'init_births':inits,'owned_clients':list(clients.values()),
                    'original_parent_after':after,'actor_pid':os.getpid(),'actor_birth':birth(os.getpid()),
                    'product_passed':False}
        except BaseException as error:
            message=repr(error)
            if message!=last_error:
                report.update(passed=False,status='QUARANTINED_LEASE_HELD',emergency_error=message)
                cleanup_checkpoint(root,report);last_error=message
            # No timeout-to-release. A missing owned-ID receipt can represent a
            # still-pending create RPC and requires independent owner evidence.
            time.sleep(5)


def main():
    linux()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--context',type=Path,required=True)
    parser.add_argument('--requester-watch-fd',type=int,required=True)
    args=parser.parse_args();context=context_load(args.context);root=args.context.parent;packet=Path(context['packet'])
    need(context['mode'].startswith('proof-') or context['mode']=='compile-portable', 'closed compiler/proof mode required')
    packet_verify(packet,context['packet_manifest_sha256'])
    for number in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(number,stop_signal)
    need(alive(context['requester']['pid'],context['requester']['birth']),'SSH-facing requester already died')
    lease=Path(context['lease'])
    # Do not unlink/recreate the canonical inode; existing lock ownership must
    # be respected. No explicit LOCK_UN is issued on the shared description.
    with os.fdopen(os.open(lease,os.O_RDONLY|os.O_NOFOLLOW),'rb') as held:
        info=os.fstat(held.fileno())
        need((info.st_uid,info.st_gid,info.st_mode & 0o7777,info.st_dev,info.st_ino)==(1000,1000,0o664,66312,17575649),'pinned existing canonical lease UID/GID/mode/device/inode differs')
        need(device_key(os.fstat(held.fileno()))==tuple(context['canonical_lease_device_inode']),
             'canonical lease inode changed before acquisition; never create or substitute one')
        need(not STOP and alive(context['requester']['pid'],context['requester']['birth']),'requester/controller interrupted before nonblocking lease')
        # One real attempt; a busy global lease is retained as a refusal, never queued.
        fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
        context['lease_owner']={'pid':os.getpid(),'birth':birth(os.getpid()),'device_inode':device_key(os.fstat(held.fileno()))}
        save(args.context,context)
        need(shutil.disk_usage('/').free>=ROOT_RESERVE+32*MIB,'512MiB host reserve plus32MiB metadata guard unavailable')
        need(shutil.disk_usage(root/'work').free>=WORK_RESERVE+GIB+CONTROL_CAP,'proof1GiB allowance plus12GiB reserve/control headroom unavailable')
        original_parent(context)
        report={'nonce':context['nonce'],'status':'STARTING_GUARDIAN','passed':False,'commands':[],
                'pid':os.getpid(),'birth':birth(os.getpid()),'started_ns':time.monotonic_ns()}
        save(root/'keeper.json',report)
        read_end,write_end=os.pipe()
        guardian=None
        command=None
        try:
            with (root/'guardian.stdout').open('wb') as output,(root/'guardian.stderr').open('wb') as error:
                guardian=subprocess.Popen([sys.executable,'-B',str(packet/'guardian.py'),'--context',str(args.context),
                    '--lease-fd',str(held.fileno()),'--controller-watch-fd',str(read_end),
                    '--requester-watch-fd',str(args.requester_watch_fd)],
                    pass_fds=(held.fileno(),read_end,args.requester_watch_fd),start_new_session=True,
                    stdin=subprocess.DEVNULL,stdout=output,stderr=error)
            os.close(read_end);read_end=-1
            report['guardian']={'pid':guardian.pid,'birth':birth(guardian.pid)};save(root/'keeper.json',report)
            deadline=time.monotonic()+120
            while True:
                need(not STOP and guardian.poll() is None,'guardian/controller stopped during admission')
                if (root/'guardian.json').exists():
                    state=json.loads((root/'guardian.json').read_text())
                    if state['status']=='RUNNING':break
                    need(state['status'] not in ('RETIRED','QUARANTINED_LEASE_HELD'),'guardian admission failed; preserve its receipt')
                need(time.monotonic()<deadline,'fresh sibling admission deadline');time.sleep(.1)
            proof=host_lease_proof(context)
            owned=json.loads((root/'owned-container.json').read_text());cid=owned['container_id']
            exact_owned(inspect(cid),context)
            report.update(status='RUNNING',container_id=cid,lease_proof=proof);save(root/'keeper.json',report)

            def requester_alive():
                ready,_,_=select.select([args.requester_watch_fd],[],[],0)
                return not ready and alive(context['requester']['pid'],context['requester']['birth'])

            def command(name,inside_argv,timeout):
                need(not STOP and requester_alive(),'requester/controller interrupted before actual actor')
                proof=host_lease_proof(context)
                argv=['docker','exec',cid,*list(map(str,inside_argv))]
                row={'name':name,'argv':argv,'started_ns':time.monotonic_ns(),'lease_before':proof}
                report['commands'].append(row);save(root/'keeper.json',report)
                with (root/(name+'.stdout')).open('wb') as stdout,(root/(name+'.stderr')).open('wb') as stderr:
                    child=subprocess.Popen(control_command(argv,'client'),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
                                           start_new_session=True,close_fds=True,
                                           preexec_fn=lambda:log_file_limit(32*MIB))
                    row.update(client_pid=child.pid,client_birth=birth(child.pid));save(root/'keeper.json',report)
                    stop=None;start=time.monotonic()
                    while child.poll() is None:
                        if STOP or not requester_alive():stop='requester/controller lost'
                        elif guardian.poll() is not None:stop='independent guardian exited'
                        elif time.monotonic()-start>timeout:stop='bounded actor timeout'
                        elif shutil.disk_usage('/').free<ROOT_RESERVE+8*MIB:stop='host root reserve plus cleanup guard reached'
                        elif shutil.disk_usage('/dev/shm').free<WORK_RESERVE:stop='ordinary host tmpfs reserve reached'
                        elif any((root/(name+suffix)).stat().st_size>32*MIB for suffix in ('.stdout','.stderr')):stop='bounded outer raw log reached'
                        if stop:
                            # Closing the lifetime pipe asks the independent
                            # guardian to kill/remove the whole owned namespace.
                            row['stop_reason']=stop;save(root/'keeper.json',report)
                            raise RuntimeError(stop)
                        time.sleep(.25)
                    row.update(exit=child.returncode,finished_ns=time.monotonic_ns(),
                               stdout_sha256=sha(root/(name+'.stdout')),stderr_sha256=sha(root/(name+'.stderr')))
                    save(root/'keeper.json',report)
                    need(child.returncode==0,'actual actor failed: '+name)
                    return row

            if context['mode'].startswith('proof-'):
                command('proof-worker',['python3','-B','/packet/proof_worker.py','--nonce',context['nonce']],180)
                raise RuntimeError('synthetic proof worker unexpectedly returned normally')
            command('compile-portable',['python3','-B','/packet/compile_portable.py','--nonce',context['nonce']],600)
            report.update(passed=True,status='PASS_COMPILE_ONLY_BEFORE_RETIREMENT')
            cleanup_checkpoint(root,report)
        except BaseException as error:
            report.update(passed=False,status='FAIL_OR_INTERRUPTED',error=repr(error))
        finally:
            if read_end!=-1:os.close(read_end)
            if write_end!=-1:
                try:os.write(write_end,b'RETIRE\n')
                except BrokenPipeError:pass
                os.close(write_end);write_end=-1
            report['retirement_requested_ns']=time.monotonic_ns();cleanup_checkpoint(root,report)
            if guardian is not None:
                # No bounded timeout-to-release. If Docker retirement is
                # indeterminate, both this descriptor and the guardian copy
                # remain held; owner review is required before any other batch.
                while guardian.poll() is None:time.sleep(.25)
                try:state=json.loads((root/'guardian.json').read_text())
                except BaseException as receipt_error:state={'retired':False,'receipt_error':repr(receipt_error)}
                report['guardian_exit']=guardian.returncode
                if not state.get('retired'):
                    report.update(passed=False,status='QUARANTINED_LEASE_HELD',guardian_loss='independent guardian exited before conclusive retirement')
                    cleanup_checkpoint(root,report)
                    report['emergency_retirement']=emergency_retire(context,root,report)
                report['retirement']=state
                if not state.get('retired') or guardian.returncode!=0 or any(state.get(key) for key in
                        ('original_parent_integrity_error','lease_proof_error','receipt_error')):
                    report.update(passed=False,status='FAIL_RETIREMENT_OR_ORIGINAL_PARENT')
                elif report['passed']:report['status']='PASS_COMPILE_ONLY_RETIRED'
            else:
                report.update(passed=False,status='FAIL_BEFORE_GUARDIAN_SPAWN')
            if report.get('receipt_error'):report.update(passed=False,status='FAIL_RECEIPT_RETIREMENT_PRESERVED')
            report['finished_ns']=time.monotonic_ns();cleanup_checkpoint(root,report)
        # The guardian has already proved complete owned namespace retirement.
        # with-close releases our last descriptor; never call LOCK_UN early.
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
