"""Unrelated lightweight host sentinel; the guardian must never signal it."""
import argparse
import time
from common import linux
linux()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--nonce',required=True)
parser.parse_args()
while True:time.sleep(1)
