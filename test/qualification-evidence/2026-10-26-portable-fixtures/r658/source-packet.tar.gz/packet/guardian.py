"""Independent lease-FD holder; retire only one exact nonce-owned sibling.

The SSH-facing processes may die. This process is a separate session and keeps
the inherited open-file description until Docker proves the whole owned PID
namespace has retired. Indeterminate cleanup quarantines the lease, not a pass.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import select
import shutil
import signal
import sys
import time
from common import (signal_owned,MEMORY, CPUSET, MIB, ROOT_RESERVE, CONTROL_CAP, INPUT_CAP, OUTPUT_CAP, linux, need, sha,
                    save, birth, alive, device_key, flock_rows, rpc, inspect,
                    original_parent, exact_owned, context_load, measured_bytes)

RETIRE = False


def interrupted(_number, _frame):
    global RETIRE
    RETIRE = True


def main():
    linux()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--context', type=Path, required=True)
    parser.add_argument('--lease-fd', type=int, required=True)
    parser.add_argument('--controller-watch-fd', type=int, required=True)
    parser.add_argument('--requester-watch-fd', type=int, required=True)
    a = parser.parse_args()
    context = context_load(a.context)
    need(context['mode'].startswith('proof-') or context['mode']=='compile-portable', 'only closed interruption proof or exact compiler mode is admitted')
    root = a.context.parent
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    for number in (signal.SIGTERM, signal.SIGINT):
        signal.signal(number, interrupted)
    lease_info = os.fstat(a.lease_fd)
    need(device_key(lease_info) == tuple(context['lease_owner']['device_inode']), 'guardian inherited another lease')
    need(flock_rows('/proc', lease_info, context['lease_owner']['pid']), 'inherited lease is not the actual acquiring controller flock')
    need(alive(context['lease_owner']['pid'], context['lease_owner']['birth']), 'controller died before guardian admission')
    report = {'nonce': context['nonce'], 'packet_manifest_sha256': context['packet_manifest_sha256'],
              'pid': os.getpid(), 'birth': birth(os.getpid()), 'lease_fd': a.lease_fd,
              'status': 'READY', 'started_ns': time.monotonic_ns(), 'retired': False,
              'scope': 'one fresh exact-ID/nonce sibling; original parent never stopped/removed'}

    def checkpoint():
        try:save(root / 'guardian.json', report)
        except OSError as receipt_error:
            # Receipt failure must never bypass namespace retirement or close
            # the sole inherited lease copy while workers may remain alive.
            report['receipt_error']=repr(receipt_error)

    def held_fd():
        sys.path.insert(0,os.environ['UWVM_CONTROL_PACKET'])
        from control import guard as control_guard
        control_guard('continuous-host-guardian')
        info = Path('/proc/self/fdinfo') / str(a.lease_fd)
        text = info.read_text()
        need(device_key(os.fstat(a.lease_fd)) == device_key(Path(context['lease']).stat()), 'lease inode replaced')
        need(any(line.startswith('lock:') and 'FLOCK' in line and 'WRITE' in line for line in text.splitlines()),
             'guardian no longer holds the inherited WRITE FLOCK descriptor')
        return {'fdinfo': text, 'kernel_locks': flock_rows('/proc', lease_info),
                'device_inode': device_key(os.fstat(a.lease_fd)), 'pid': os.getpid(), 'lease_fd': a.lease_fd,
                'at_ns': time.monotonic_ns(), 'guardian_birth': report['birth']}

    checkpoint()
    container_id = None
    create_attempted = False
    create_completed = False
    init = None
    stop_reason = None
    error = None
    try:
        report['lease_before_create'] = held_fd()
        original_parent(context)
        need(not inspect(context['container_name'], absent=True), 'fresh nonce-owned name already exists')
        uid, gid = context['uid'], context['gid']
        argv = ['docker', 'create', '--name', context['container_name'], '--hostname', context['container_name'],
                '--label', 'uwvm.r18.nonce=' + context['nonce'],
                '--label', 'uwvm.r18.packet=' + context['packet_manifest_sha256'],
                '--cgroup-parent', 'uwvmros.slice', '--memory', str(MEMORY), '--memory-swap', str(MEMORY), '--cpuset-cpus', CPUSET,
                '--cgroupns=private', '--pids-limit', '2048', '--read-only', '--network=none',
                '--log-driver=none', '--user', f'{uid}:{gid}', '--cap-drop=ALL',
                '--security-opt', 'no-new-privileges',
                '--tmpfs', f'/tmp:rw,exec,nosuid,nodev,size={512*MIB},uid={uid},gid={gid},mode=1777',
                '--tmpfs', f'/run:rw,nosuid,nodev,size={16*MIB},uid={uid},gid={gid},mode=700',
                '--mount', 'type=bind,source=' + str(root/'work') + ',target=/work',
                '--mount', 'type=bind,source=/proc,target=/host/proc,readonly,bind-recursive=readonly,bind-propagation=rprivate',
                '--mount', 'type=bind,source=/sys/fs/cgroup/uwvmros.slice,target=/host/budget,readonly,bind-recursive=readonly,bind-propagation=rprivate',
                '--mount', 'type=bind,source=' + context['lease'] + ',target=/host' + context['lease'] + ',readonly',
                '--mount', 'type=bind,source=' + str(root) + ',target=/host' + str(root) + ',readonly',
                '--mount', 'type=bind,source=' + context['packet'] + ',target=/packet,readonly',
                '--mount', 'type=bind,source=' + str(root) + ',target=/context,readonly',
                '--env', 'PYTHONDONTWRITEBYTECODE=1', '--env', 'UWVM_R18_CONTEXT=/context/context.json',
                '--env', 'UWVM_R18_NONCE=' + context['nonce'], '--workdir', '/work',
                '--mount', 'type=bind,source=/home/macromodel/Documents/uwvm2-ros-test/platform-chat-01/sdk,target=/base-sdk,readonly',
                '--mount', 'type=bind,source=/home/macromodel/.local/bin,target=/tool-bin,readonly',
                '--mount', 'type=bind,source=/home/macromodel/.local/share/xmake,target=/tool-program,readonly',
                '--entrypoint', '/bin/sleep', context['parent']['image'], 'infinity']
        report['create_argv'] = argv
        create_attempted = True; checkpoint()
        result = rpc(argv, timeout=60)
        container_id = result.stdout.decode().strip()
        need(len(container_id) == 64 and all(c in '0123456789abcdef' for c in container_id), 'create did not return the full owned ID')
        create_completed = True
        row = exact_owned(inspect(container_id), context)
        need(not row['State']['Running'], 'fresh owned container unexpectedly started')
        report['container_id'] = container_id
        save(root/'owned-container.json', {'container_id': container_id, 'nonce': context['nonce'], 'created': row})
        checkpoint()
        # Only the guardian starts a container. If the requester/controller was
        # lost during create, remove the never-started child without starting it.
        need(alive(context['lease_owner']['pid'], context['lease_owner']['birth']) and
             alive(context['requester']['pid'], context['requester']['birth']), 'requester/controller lost before start')
        need(not RETIRE, 'guardian interrupted before start')
        rpc(['docker', 'start', container_id], timeout=60)
        row = exact_owned(inspect(container_id), context)
        need(row['State']['Running'], 'owned child did not start')
        pid = row['State']['Pid']
        init = {'pid': pid, 'birth': birth(pid), 'cgroup': Path(f'/proc/{pid}/cgroup').read_text().strip()}
        need(init['cgroup'].startswith('0::') and '\n' not in init['cgroup'], 'owned init must have one unified cgroup')
        report['lease_current'] = held_fd()
        report.update(status='RUNNING', init=init, started_container_ns=time.monotonic_ns())
        save(root/'owned-container.json', {'container_id': container_id, 'nonce': context['nonce'], 'started': row, 'init': init})
        checkpoint()
        deadline = time.monotonic() + (300 if context['mode'].startswith('proof') else 43200)
        metadata_at=0
        while True:
            if RETIRE:
                stop_reason = 'guardian received handled interrupt'; break
            if time.monotonic() > deadline:
                stop_reason = 'owned batch wall timeout'; break
            for fd, label in ((a.controller_watch_fd, 'controller'), (a.requester_watch_fd, 'SSH-facing requester')):
                ready, _, _ = select.select([fd], [], [], 0)
                if ready:
                    data = os.read(fd, 4096)
                    stop_reason = label + (' requested retirement' if data else ' died/closed lifetime pipe')
                    break
            if stop_reason:
                break
            if not alive(context['lease_owner']['pid'], context['lease_owner']['birth']):
                stop_reason = 'controller birth no longer alive'; break
            if not alive(context['requester']['pid'], context['requester']['birth']):
                stop_reason = 'requester birth no longer alive'; break
            report['lease_current'] = held_fd(); checkpoint()
            if time.monotonic()>=metadata_at:
                original_parent(context)
                row = exact_owned(inspect(container_id), context)
                need(row['State']['Running'] and row['State']['Pid'] == init['pid'] and alive(init['pid'], init['birth']),
                     'owned child unexpectedly stopped/restarted')
                need(measured_bytes(root) <= context['host_budget_bytes'], 'owned staged/output/control budget exceeded')
                work_bytes=measured_bytes(root/'work')
                output_bytes=measured_bytes(root/'work/ros-product-build-r18') if (root/'work/ros-product-build-r18').exists() else 0
                need(output_bytes<=OUTPUT_CAP and work_bytes-output_bytes<=INPUT_CAP,
                     'independent8GiB app-output or32GiB complete-input budget exceeded')
                control_bytes=sum(path.stat().st_blocks*512 for path in root.iterdir() if path.is_file())
                need(control_bytes<=CONTROL_CAP,'128MiB host control-record budget exceeded')
                need(shutil.disk_usage('/').free >= ROOT_RESERVE,'512MiB host reserve reached')
                metadata_at=time.monotonic()+15
            time.sleep(.25)
    except BaseException as caught:
        error = repr(caught)
        stop_reason = stop_reason or 'guardian admission/runtime failure'
    finally:
        report.update(status='RETIRING', stop_reason=stop_reason, error=error,
                      retirement_requested_ns=time.monotonic_ns())
        checkpoint()
        if context['mode'].startswith('proof') and init is not None:
            # A bounded proof-only barrier exposes the interval after controller
            # death but before namespace retirement. It is never used by builds.
            report['lease_at_proof_barrier'] = held_fd()
            report['status'] = 'PROOF_RETIREMENT_BARRIER'; checkpoint()
            deadline = time.monotonic() + 45
            try:
                while time.monotonic() < deadline:
                    release = root/'proof-release.json'
                    if release.exists():
                        value = json.loads(release.read_text())
                        if value['nonce'] == context['nonce'] and value['packet_manifest_sha256'] == context['packet_manifest_sha256']:
                            report['proof_release_sha256'] = sha(release); break
                    held_fd(); time.sleep(.1)
            except BaseException as barrier_error:
                report['proof_barrier_error']=repr(barrier_error)
        # Never close the inherited FD while container ownership/retirement is
        # indeterminate. A failed Docker RPC quarantines the lease and retries.
        last_error = None
        while True:
            try:
                try:report['lease_during_retirement'] = held_fd()
                except BaseException as lease_error:report['lease_proof_error']=repr(lease_error)
                if not create_attempted:
                    break  # never retire a pre-existing name when this invocation created no resource
                row = inspect(container_id or context['container_name'], absent=True)
                if row is None:
                    need(not create_attempted or create_completed or container_id is not None,
                         'create RPC was indeterminate; late owned creation cannot yet be excluded')
                    break
                row = exact_owned(row, context)
                if container_id is not None:
                    need(row['Id'] == container_id, 'never retire a replacement container')
                else:
                    container_id = row['Id']; report['container_id'] = container_id
                if row['State']['Running']:
                    rpc(['docker', 'kill', '--signal', 'KILL', container_id], timeout=30)
                row = exact_owned(inspect(container_id), context)
                need(not row['State']['Running'], 'owned namespace still running')
                if init:
                    need(not alive(init['pid'], init['birth']), 'owned original init birth remains live')
                    relative = init['cgroup'][3:].lstrip('/')
                    group = Path('/sys/fs/cgroup')/relative
                    if group.exists():
                        need(not (group/'cgroup.procs').read_text().split(), 'owned cgroup still has writers')
                rpc(['docker', 'rm', container_id], timeout=30)
                need(inspect(container_id, absent=True) is None, 'owned container still exists after removal')
                break
            except BaseException as cleanup_error:
                message = repr(cleanup_error)
                if message != last_error:
                    report.update(status='QUARANTINED_LEASE_HELD', cleanup_error=message,
                                  quarantine_since_ns=report.get('quarantine_since_ns', time.monotonic_ns()))
                    checkpoint(); last_error = message
                # Deliberately no timeout-to-release and no parent/container
                # fallback kill. Owner intervention is needed if Docker is lost.
                time.sleep(5)
        # Docker clients can outlive a killed keeper and still own log FDs.
        # Retire only birth-recorded clients whose actual argv names this exact
        # newly owned container ID, after the namespace itself is gone.
        clients=[]
        while True:
            try:
                if container_id is not None:
                    selected={item['pid']:item for item in clients}
                    for path in Path('/proc').iterdir():
                        if not path.name.isdecimal():continue
                        try:
                            argv=(path/'cmdline').read_bytes().split(b'\0')
                            if argv and Path(os.fsdecode(argv[0])).name=='docker' and b'exec' in argv and container_id.encode() in argv:
                                selected[int(path.name)]={'pid':int(path.name),'birth':birth(int(path.name))}
                        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
                    clients=list(selected.values())
                for client in clients:
                    if alive(client['pid'],client['birth']):
                        try:signal_owned(client['pid'],client['birth'],signal.SIGKILL)
                        except ProcessLookupError:pass
                if not any(alive(client['pid'],client['birth']) for client in clients):break
                time.sleep(.1)
            except BaseException as client_error:
                report.update(status='QUARANTINED_LEASE_HELD',client_retirement_error=repr(client_error))
                checkpoint();time.sleep(5)
        report.update(status='RETIRED', retired=True, container_id=container_id,
                      retired_ns=time.monotonic_ns(), retired_owned_docker_clients=clients)
        try:report['lease_before_close']=held_fd()
        except BaseException as lease_error:report['lease_proof_error']=repr(lease_error)
        try:
            report['original_parent_after'] = original_parent(context)
        except BaseException as parent_error:
            report['original_parent_integrity_error'] = repr(parent_error)
        checkpoint()
        # Closing this copy is safe only here. Do not issue LOCK_UN: that would
        # unlock the shared open-file description while another copy survives.
        os.close(a.lease_fd)
    return 0 if error is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
