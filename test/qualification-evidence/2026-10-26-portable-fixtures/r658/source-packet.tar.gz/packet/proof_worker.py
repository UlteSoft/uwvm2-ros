"""Harmless synthetic owner/leaf; only the Linux guardian proof may use it."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from common import signal_owned,guard,need,save,birth,alive,child_cgroup


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--nonce',required=True)
    parser.add_argument('--leaf',action='store_true')
    parser.add_argument('--kill-owner',action='store_true')
    parser.add_argument('--inspect-owner',action='store_true')
    args=parser.parse_args()
    context=json.loads(Path('/context/context.json').read_text())
    need(args.nonce==context['nonce'] and context['mode'].startswith('proof'),'synthetic control nonce/mode differs')
    path=Path('/work/proof');path.mkdir(exist_ok=True)
    if args.leaf:
        proof=guard();save(path/'leaf.json',{'nonce':args.nonce,'pid':os.getpid(),'birth':birth(os.getpid()),'cgroup':proof})
        while True:time.sleep(1)
    if args.kill_owner or args.inspect_owner:
        control_cgroup=child_cgroup()
        row=json.loads((path/'worker.json').read_text())
        need(row['nonce']==args.nonce,'synthetic controller nonce differs')
        leaf=row['leaf'];need(alive(leaf['pid'],leaf['birth']),'synthetic descendant is absent/reused')
        if args.kill_owner:
            need(alive(row['pid'],row['birth']),'synthetic owner is absent/reused')
            need(args.nonce in Path(f"/proc/{row['pid']}/cmdline").read_bytes().decode().split('\x00'),
                 'synthetic owner argv nonce differs')
            signal_owned(row['pid'],row['birth'],signal.SIGKILL)
        print(json.dumps({'nonce':args.nonce,'owner_alive':alive(row['pid'],row['birth']),
                          'leaf_alive':alive(leaf['pid'],leaf['birth']),'leaf':leaf,'control_cgroup':control_cgroup,'observed_ns':time.monotonic_ns()}))
        return
    proof=guard()
    child=subprocess.Popen([sys.executable,'-B','/packet/proof_worker.py','--leaf','--nonce',args.nonce],
                           stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    deadline=time.monotonic()+15
    while not (path/'leaf.json').exists():
        need(child.poll() is None and time.monotonic()<deadline,'synthetic leaf failed');time.sleep(.05)
    leaf=json.loads((path/'leaf.json').read_text())
    save(path/'worker.json',{'nonce':args.nonce,'pid':os.getpid(),'birth':birth(os.getpid()),
                           'leaf':leaf,'cgroup':proof,'created_ns':time.monotonic_ns()})
    while True:time.sleep(1)


if __name__=='__main__':main()
