"""One real competing canonical-flock attempt, for the lightweight proof only."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import time
from common import linux,birth,device_key

linux()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lease',type=Path,required=True)
args=parser.parse_args()
with os.fdopen(os.open(args.lease,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
    held=False
    try:
        fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);held=True
    except BlockingIOError:pass
    print(json.dumps({'acquired':held,'pid':os.getpid(),'birth':birth(os.getpid()),
                      'device_inode':device_key(os.fstat(stream.fileno())),'observed_ns':time.monotonic_ns()}))
    if held:fcntl.flock(stream,fcntl.LOCK_UN)
