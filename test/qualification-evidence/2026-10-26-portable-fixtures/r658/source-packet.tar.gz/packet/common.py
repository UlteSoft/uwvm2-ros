"""Linux-only source packet support; no subject execution at import time."""
from __future__ import annotations
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import shutil
import stat
import subprocess
import sys
import time

GIB = 1024 ** 3
MIB = 1024 ** 2
MEMORY = 64 * GIB
CPUSET = '0,2,4,6,16-31'
BASE_ID = 'sha256:0eb15828def0e4ff4b35d3e820a58e3566e4ddf3778d39d70fa25b3ec268af66'
SUBJECT_ID = 'sha256:d7264184e0eae7e326b0029d27d64843b430f6a7ce26c7eb3e2f862a57f7b9e3'
INPUT_CAP = 32 * GIB
OUTPUT_CAP = 8 * GIB
WORK_RESERVE = 12 * GIB
ROOT_RESERVE = 512 * MIB
CONTROL_CAP = 128 * MIB
WORK_CAP = 24 * GIB
BUDGET_PATH = "/sys/fs/cgroup/uwvmros.slice"
BUDGET_INODE = 20624
CURRENT_BOOT = "815b614a-e0a5-4600-9d7f-139b323d8190"


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def linux():
    need(sys.platform == 'linux', 'Linux only; do not execute or import this controller on Mac')
    need(sys.flags.optimize == 0, 'unoptimized Python is required')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    if Path(__file__).parent != Path('/packet'):
        need(os.environ.get('UWVM_CONTROL_ADMISSION'), 'host controllers require the dedicated control envelope')
        sys.path.insert(0,os.environ['UWVM_CONTROL_PACKET'])
        from control import record
        record('host-'+Path(sys.argv[0]).stem)


def control_command(argv,role='rpc'):
    if os.environ.get('UWVM_CONTROL_ADMISSION'):
        sys.path.insert(0,os.environ['UWVM_CONTROL_PACKET'])
        from control import command
        return command(argv,role)
    need(Path(__file__).parent==Path('/packet'),'unadmitted host control client')
    return list(map(str,argv))



def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def readonly_fd(path):
    """Open an original without reading until its actual FD mount proves ro."""
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        information=Path(f'/proc/self/fdinfo/{descriptor}').read_text()
        mount_id=next(line.split()[1] for line in information.splitlines() if line.startswith('mnt_id:'))
        rows=[line.split() for line in Path('/proc/self/mountinfo').read_text().splitlines() if line.split()[0]==mount_id]
        need(len(rows)==1 and 'ro' in rows[0][5].split(','),'original actual file descriptor is on a writable mount: '+str(path))
        return descriptor
    except BaseException:
        os.close(descriptor);raise


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    need(len(data) <= 64 * MIB, 'bounded JSON receipt exceeded64MiB')
    with temporary.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def birth(pid, proc=Path('/proc')):
    return (proc / str(pid) / 'stat').read_text().rsplit(') ', 1)[1].split()[19]


def alive(pid, expected, proc=Path('/proc')):
    try:
        fields = (proc / str(pid) / 'stat').read_text().rsplit(') ', 1)[1].split()
        return fields[19] == str(expected) and fields[0] != 'Z'
    except (FileNotFoundError, ProcessLookupError):
        return False


def device_key(info):
    return (os.major(info.st_dev), os.minor(info.st_dev), info.st_ino)


def flock_rows(proc, info, owner=None):
    rows = []
    for line in (Path(proc) / 'locks').read_text().splitlines():
        fields = line.split()
        if len(fields) < 8 or fields[1] != 'FLOCK' or fields[3] != 'WRITE':
            continue
        device = fields[5].split(':')
        if len(device) != 3:
            continue
        actual = (int(device[0], 16), int(device[1], 16), int(device[2]))
        if actual == device_key(info) and (owner is None or int(fields[4]) == owner):
            rows.append(line)
    return rows


def packet_verify(packet, expected):
    need(sha(packet / 'packet-manifest.json') == expected, 'frozen packet manifest differs')
    rows = json.loads((packet / 'packet-manifest.json').read_text())['files']
    for row in rows:
        relative = Path(row['path'])
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe packet path')
        path = packet / relative
        need(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes']
             and sha(path) == row['sha256'], 'packet changed: ' + row['path'])
    return rows


def host_lease_proof(context, proc=Path('/proc'), prefix=''):
    """Require the actual live acquiring PID plus its kernel WRITE FLOCK."""
    if not prefix:
        sys.path.insert(0,os.environ['UWVM_CONTROL_PACKET'])
        from control import guard as control_guard
        control_guard('continuous-host-lease')
    owner = context['lease_owner']
    guardian = json.loads((Path(prefix + context['context']) / 'guardian.json').read_text())
    need(guardian['nonce'] == context['nonce'] and guardian['packet_manifest_sha256'] == context['packet_manifest_sha256'],
         'guardian nonce/packet differs')
    need(guardian['status'] in ('READY', 'RUNNING'), 'guardian revoked admissions')
    need(alive(owner['pid'], owner['birth'], proc), 'actual host flock-acquiring controller died')
    need(alive(context['requester']['pid'], context['requester']['birth'], proc), 'SSH-facing requester died')
    need(alive(guardian['pid'], guardian['birth'], proc), 'independent guardian died')
    lease = Path(prefix + context['lease'])
    info = lease.stat()
    need(device_key(info) == tuple(owner['device_inode']), 'canonical lease inode changed')
    locks = flock_rows(proc, info, owner['pid'])
    need(len(locks) == 1, 'the named controller is not the actual canonical WRITE FLOCK owner')
    if prefix:
        # Container actors cannot inspect unrelated host FDs under Yama.
        # The guardian reads its OWN actual FD; host-side admission still
        # performs direct procfs verification and workers independently read
        # the live kernel FLOCK row for the canonical inode above.
        snapshot = guardian['lease_current']
        need(snapshot['pid'] == guardian['pid'] and snapshot['guardian_birth'] == guardian['birth']
             and snapshot['lease_fd'] == guardian['lease_fd'], 'guardian self-observation identity differs')
        need(tuple(snapshot['device_inode']) == device_key(info), 'guardian self-observed another lease inode')
        need(0 <= time.monotonic_ns()-snapshot['at_ns'] <= 5_000_000_000, 'guardian FD observation is stale')
        fdinfo = snapshot['fdinfo']
    else:
        fd = proc / str(guardian['pid']) / 'fdinfo' / str(guardian['lease_fd'])
        fdinfo = fd.read_text()
        held = (proc / str(guardian['pid']) / 'fd' / str(guardian['lease_fd'])).stat()
        need(device_key(held) == device_key(info), 'guardian inherited another inode')
    need(any(line.startswith('lock:') and 'FLOCK' in line and 'WRITE' in line
             for line in fdinfo.splitlines()), 'guardian did not inherit the held flock descriptor')
    return {'owner': owner, 'flock': locks, 'guardian_pid': guardian['pid'],
            'guardian_birth': guardian['birth'], 'guardian_fdinfo': fdinfo,
            'observed_monotonic_ns': time.monotonic_ns()}


def child_cgroup():
    linux()
    root = Path('/sys/fs/cgroup')
    membership = Path('/proc/self/cgroup').read_text().strip()
    need(membership.startswith('0::') and '\n' not in membership, 'one actual unified cgroup required')
    observed = {name: (root / name).read_text().strip() for name in
                ('memory.max', 'memory.swap.max', 'cpuset.cpus.effective', 'memory.events')}
    need(observed['memory.max'] == str(MEMORY) and observed['memory.swap.max'] == '0',
         'actual process is outside64GiB/zero-swap limits')
    need(observed['cpuset.cpus.effective'] == CPUSET, 'actual twenty-CPU cpuset differs')
    need(str(os.getpid()) in (root / 'cgroup.procs').read_text().split(), 'actual process not in inspected cgroup')
    need(os.getuid()==1000 and os.geteuid()==1000 and os.getgid()==1000,'actual child unprivileged UID/GID differs')
    status=dict(line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    need(status['Seccomp'].strip()=='2' and all(int(status[key].strip(),16)==0 for key in ('CapInh','CapPrm','CapEff','CapBnd','CapAmb')),'actual actor seccomp/zero-capability state differs')
    return {'actual_security':{key:status[key].strip() for key in ('Seccomp','Seccomp_filters','CapInh','CapPrm','CapEff','CapBnd','CapAmb')},'pid': os.getpid(), 'birth': birth(os.getpid()), 'membership': membership,
            'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'shared_ancestor': shared_budget('/host/budget'), **observed}


def guard(_lease=None):
    """Executed by every heavy actor, before any source/provider/build mutation."""
    proof = child_cgroup()
    context_path = Path(os.environ['UWVM_R18_CONTEXT'])
    context = json.loads(context_path.read_text())
    need(os.environ['UWVM_R18_NONCE'] == context['nonce'], 'worker nonce differs')
    need(proof['boot_id'] == context['boot_id'], 'host rebooted')
    proof['lease'] = host_lease_proof(context, Path('/host/proc'), '/host')
    mount_rows = []
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        fields = line.split(); destination = fields[4]
        if destination in ('/host','/packet','/context') or any(destination.startswith(prefix+'/') for prefix in ('/host','/packet','/context')):
            need('ro' in fields[5].split(','), 'a shared/control submount is writable: '+line)
            mount_rows.append(line)
    need(mount_rows, 'shared/control read-only mount proof missing')
    need(shutil.disk_usage('/work').free >= WORK_RESERVE, '12GiB ordinary host tmpfs reserve reached')
    root_witness=Path('/host'+context['lease'])
    need(root_witness.stat().st_dev==context['host_root_device'], 'host root-filesystem witness is on another device')
    need(shutil.disk_usage(root_witness).free >= ROOT_RESERVE, '512MiB host root reserve reached')
    packet_root = Path('/packet')
    packet_verify(packet_root, context['packet_manifest_sha256'])
    need(sha(packet_root/'admission.json') == '201917163c53726c34b7964632580b8b460b0a47de00f7613a02396cf2d692f1', 'sealed admission snapshot changed')
    admission = json.loads((packet_root/'admission.json').read_text())
    need(admission['boot_id'] == context['boot_id'] and admission['idle_anchor']['id'] == context['parent']['id'], 'SDK01 admission belongs to another boot/anchor')
    for item in json.loads((packet_root/'sdk-inputs.json').read_text()):
        source = packet_root/'sdk-inputs'/item['path']
        need(source.stat().st_size == item['bytes'] and sha(source) == item['sha256'], 'SDK01 source/provider identity changed')
    proof['sdk01_source_provider_pins'] = len(json.loads((packet_root/'sdk-inputs.json').read_text()))
    proof['shared_admission_sha256'] = sha(packet_root/'admission.json')
    from input_guard import verify_inputs
    proof['compiler_inputs'] = verify_inputs()
    proof['shared_readonly_mounts'] = mount_rows
    return proof


def rpc(argv, timeout=30, limit=4*MIB, check=True):
    result = subprocess.run(control_command(argv), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=timeout)
    need(len(result.stdout) <= limit and len(result.stderr) <= limit, 'bounded Docker metadata output exceeded')
    if check:
        need(result.returncode == 0, 'Docker metadata command failed: ' + repr(argv) + ': ' + result.stderr[-4096:].decode(errors='replace'))
    return result


def inspect(identity, absent=False):
    result = rpc(['docker', 'inspect', identity], check=False)
    if result.returncode:
        # Match only Docker's exact missing-identity diagnostic and empty
        # inspect result. CLI releases differ in prefix capitalization.
        expected = str(identity).encode().lower()
        missing = result.stderr.strip().lower() in {
            b'error: no such object: ' + expected,
            b'error: no such container: ' + expected,
            b'error response from daemon: no such object: ' + expected,
            b'error response from daemon: no such container: ' + expected,
        }
        need(absent and result.returncode == 1 and missing and result.stdout.strip() == b'[]',
             'Docker inspect failed without proving absence: ' + result.stderr[-4096:].decode(errors='replace'))
        return None
    rows = json.loads(result.stdout)
    need(len(rows) == 1, 'one exact Docker identity required')
    return rows[0]


def original_parent(context):
    row = inspect(context['parent']['id'])
    expected = context['parent']
    need(row['Id'] == expected['id'] and row['State']['Running'] and row['State']['Pid'] == expected['pid'],
         'existing original parent container changed/restarted')
    need(alive(expected['pid'], expected['birth']), 'original parent init PID was reused')
    need(row['Image'] == expected['image'], 'original parent image changed')
    need({key:row['HostConfig'].get(key) for key in context['parent_config']}==context['parent_config'], 'original parent configuration changed')
    need(row['HostConfig']['CgroupParent']=='uwvmros.slice', 'anchor outside shared slice')
    host_membership(row['State']['Pid'])
    return {'id': row['Id'], 'pid': row['State']['Pid'], 'birth': birth(row['State']['Pid']), 'image': row['Image']}


def exact_owned(row, context):
    need(row is not None and row['Id'] != context['parent']['id'], 'never retire the existing parent container')
    need(row['Name'] == '/' + context['container_name'], 'owned container name differs')
    labels = row['Config'].get('Labels') or {}
    need(labels.get('uwvm.r18.nonce') == context['nonce'] and labels.get('uwvm.r18.packet') == context['packet_manifest_sha256'],
         'container nonce/packet ownership not proved')
    need(row['Image'] == context['parent']['image'], 'owned child image differs')
    need(row['HostConfig']['CgroupParent']=='uwvmros.slice', 'job outside aggregate budget')
    shared_budget(BUDGET_PATH)
    if row['State']['Running']:host_membership(row['State']['Pid'])
    need(row['HostConfig']['Memory'] == MEMORY and row['HostConfig']['MemorySwap'] == MEMORY,
         'owned child Docker64GiB/zero-swap configuration differs')
    need(row['HostConfig']['ReadonlyRootfs'] is True and row['HostConfig']['CpusetCpus'] == CPUSET,
         'owned child root/cpuset configuration differs')
    need(not row['HostConfig']['Privileged'] and not row['HostConfig'].get('CapAdd') and
         row['HostConfig'].get('CapDrop')==['ALL'],'owned child privileges differ')
    bindings={mount['Destination']:mount for mount in row['Mounts'] if mount['Type']=='bind'}
    expected={'/work':str(Path(context['context'])/'work'), '/packet':context['packet'],
              '/context':context['context'], '/host/proc':'/proc',
              '/host'+context['lease']:context['lease'], '/host'+context['context']:context['context'], '/host/budget':BUDGET_PATH,
              '/base-sdk':'/home/macromodel/Documents/uwvm2-ros-test/platform-chat-01/sdk',
              '/tool-bin':'/home/macromodel/.local/bin', '/tool-program':'/home/macromodel/.local/share/xmake'}
    need(set(bindings)==set(expected),'unreviewed bind mounts')
    need(bindings['/work']['RW'] and all(not value['RW'] for name,value in bindings.items() if name!='/work'),
         'shared/control/packet bindings must be read-only')
    for name,mount in bindings.items():
        supplied=Path(mount['Source']); actual=supplied.resolve(strict=True)
        need(str(supplied)==expected[name], 'unexpected bind source/destination pair')
        # The real /proc mount is a read-only metadata surface. No proc PID
        # descendant or root magic-link path may be a Docker mount source.
        if name=='/host/proc':
            need(supplied==Path('/proc') and actual==Path('/proc') and not mount['RW'], 'host proc metadata mount differs')
        else:
            need(supplied.is_absolute() and not supplied.is_relative_to('/proc') and not actual.is_relative_to('/proc'),
                 'Docker proc descendant/magic-link bind sources are forbidden')
    return row


def measured_bytes(root):
    return sum(path.lstat().st_blocks * 512 for path in Path(root).rglob('*')
               if path.is_file() and not path.is_symlink())


def context_load(path):
    context = json.loads(Path(path).read_text())
    need(re.fullmatch('[0-9a-f]{32}', context['nonce']) is not None, 'invalid ownership nonce')
    need(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == context['boot_id'], 'boot changed')
    return context


def signal_owned(pid, expected_birth, number):
    """Kernel pidfd plus matching birth; no PID-number fallback."""
    need(hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal'), 'pidfd support required; block rather than signal an ambiguous PID')
    try: descriptor = os.pidfd_open(pid, 0)
    except ProcessLookupError: return False
    try:
        if not alive(pid, expected_birth):
            try: need(birth(pid) == str(expected_birth), 'refuse reused/wrong PID birth')
            except (FileNotFoundError, ProcessLookupError): return False
            return False
        need(birth(pid) == str(expected_birth), 'refuse reused/wrong PID birth')
        try: signal.pidfd_send_signal(descriptor, number); return True
        except ProcessLookupError: return False
    finally: os.close(descriptor)


def log_file_limit(limit):
    resource.setrlimit(resource.RLIMIT_FSIZE,(limit,limit))


def shared_budget(path):
    root=Path(path)
    need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==CURRENT_BOOT,'shared admission boot changed')
    need(root.stat().st_ino==BUDGET_INODE,'shared ancestor was recreated')
    observed={name:(root/name).read_text().strip() for name in ('memory.max','memory.swap.max','memory.current','memory.events')}
    need(observed['memory.max']==str(MEMORY) and observed['memory.swap.max']=='0','aggregate64GiB/0swap differs')
    return {'actual_path':str(root),'host_path':BUDGET_PATH,'inode':BUDGET_INODE,**observed}


def host_membership(pid):
    shared=shared_budget(BUDGET_PATH)
    membership=Path('/proc',str(pid),'cgroup').read_text().strip()
    need(membership.startswith('0::/uwvmros.slice/') and '\n' not in membership,'actual actor outside shared ancestor')
    root=Path('/sys/fs/cgroup')/membership[3:].lstrip('/')
    need((root/'memory.max').read_text().strip()==str(MEMORY) and (root/'memory.swap.max').read_text().strip()=='0','actual actor limit differs')
    need(str(pid) in (root/'cgroup.procs').read_text().split(),'actor absent from actual leaf')
    return {'pid':pid,'birth':birth(pid),'membership':membership,'ancestor':shared}
