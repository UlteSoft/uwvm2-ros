"""Linux host entry point: proof-only controller; full input staging remains hard-blocked.

This packet is source-only. The qualification branch cannot dispatch a keeper
until the actual same-packet Linux interruption proof has passed and is pinned.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import uuid
from common import (signal_owned,host_membership,GIB,MIB,MEMORY,CPUSET,INPUT_CAP,OUTPUT_CAP,CONTROL_CAP,WORK_RESERVE,
                    ROOT_RESERVE,linux,need,sha,save,birth,alive,device_key,flock_rows,
                    packet_verify,host_lease_proof,original_parent,inspect,exact_owned,rpc)

IMAGE='sha256:f4ae8305743549c43a4f76b305bf8c90d9c35bee26d76523e93799a400223b19'
STOP=False


def stop_signal(_number,_frame):
    global STOP
    STOP=True


def wait_for(predicate,timeout,message):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        need(not STOP,'SSH-facing request interrupted')
        result=predicate()
        if result:return result
        time.sleep(.1)
    raise RuntimeError(message)


def proof_validate(path,expected,packet_digest,boot,parent):
    need(sha(path)==expected,'actual guardian proof digest differs')
    proof=json.loads(path.read_text())
    need(proof.get('passed') is True and proof['status']=='PASS_GUARDIAN_ONLY', 'actual guardian proof is absent/incomplete/failed')
    need(proof['packet_manifest_sha256']==packet_digest and proof['boot_id']==boot and proof['parent']==parent,
         'guardian proof belongs to another packet/boot/parent identity')
    need(proof.get('control_source_manifest_sha256')=='207d75c523ce8b4a20adce153eb7cb116765f04394803c11e548a3decfb1a808','proof lacks exact shared control entry')
    need(proof['control_envelope']['shared_ancestor']['memory.max']==str(MEMORY) and proof['control_envelope']['memory.swap.max']=='0','proof lacks actual shared host control budget')
    need(sha(proof['control_admission_path'])==proof['control_envelope']['admission_sha256'],'proof control admission changed')
    need({row['case'] for row in proof['cases']}=={'host-controller-loss','inside-controller-loss'},'both real interruption cases required')
    for item in proof['cases']:
        relative=Path(item['path']);need(not relative.is_absolute() and '..' not in relative.parts,'unsafe proof receipt path')
        raw=path.parent/relative;need(sha(raw)==item['sha256'],'raw interruption receipt changed')
        row=json.loads(raw.read_text())
        need(row['passed'] is True and row['before_attempt']['acquired'] is False and
             row['after_loss_attempt']['acquired'] is False and row['after_retirement_attempt']['acquired'] is True,
             'real competing lock outcomes do not prove continuous ownership')
        need(row['worker_after_loss']['leaf_alive'] is True and row['child_still_running_after_loss'] is True,
             'proof did not cover a still-live owned descendant')
        need(row['after_loss_attempt']['observed_ns']<row['release_ns']<row['guardian']['retired_ns']<=
             row['after_retirement_attempt']['observed_ns'],'lock/retirement time ordering invalid')
        need(row['guardian']['retired'] is True and row['guardian']['status']=='RETIRED' and
             row['container_absent'] is True and row['parent_before']==row['parent_after'] and
             row['sentinel_before']==row['sentinel_after'],'owned retirement or unrelated identity proof missing')
        need(not any(row['guardian'].get(key) for key in ('error','lease_proof_error','receipt_error','proof_barrier_error','original_parent_integrity_error','client_retirement_error')),
             'guardian proof contains an unresolved ownership/receipt/integrity failure')
        need(all(attempt['device_inode']==row['lease_device_inode'] for attempt in
                 (row['before_attempt'],row['after_loss_attempt'],row['after_retirement_attempt'])),
             'competing attempts did not address the same canonical lease inode')
        need(row['guardian_fd_device_inode']==row['lease_device_inode'],'guardian held another descriptor inode')
        need(row['worker_after_loss']['owner_alive'] is (row['case']=='host-controller-loss'),
             'actual synthetic owner outcome does not match the chosen interruption')
        need('FLOCK' in row['inherited_fd_after_loss'] and 'WRITE' in row['inherited_fd_after_loss'],
             'inherited guardian lease FD was not observed')
        control=row['worker_after_loss']['control_cgroup']
        need(control['memory.max']==str(MEMORY) and control['memory.swap.max']=='0', 'actual inspect-control limits differ')
        for key in ('worker','leaf'):
            actual=row['synthetic'][key]['cgroup']
            need(actual['memory.max']==str(MEMORY) and actual['memory.swap.max']=='0' and
                 actual['cpuset.cpus.effective']==CPUSET,'synthetic child actual limits differ')
        for source in row['raw_files']:
            relative=Path(source['path']);need(not relative.is_absolute() and '..' not in relative.parts,'unsafe raw proof file path')
            need(sha(raw.parent/relative)==source['sha256'],'raw proof evidence changed: '+str(relative))
    return proof


def main():
    linux()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=('prove-guardian','qualify'),required=True)
    parser.add_argument('--parent-id',required=True)
    parser.add_argument('--expected-boot-id',required=True)
    parser.add_argument('--packet-manifest-sha256',required=True)
    parser.add_argument('--accepted15-receipt-sha256')
    parser.add_argument('--guardian-proof',type=Path)
    parser.add_argument('--guardian-proof-sha256')
    args=parser.parse_args();packet=Path(__file__).resolve().parent
    envelope=json.loads((packet/'envelope-pin.json').read_text())
    control_root=Path(os.environ['UWVM_CONTROL_PACKET'])
    need(str(control_root)==envelope['source_remote'] and sha(control_root/'packet-manifest.json')==envelope['source_manifest_sha256'],'own control envelope source differs')
    from control import guard as control_guard
    control_admission=control_guard('requester')
    if args.mode=='qualify':
        need(args.guardian_proof is not None and args.guardian_proof_sha256, 'same-bundle own raw interruption proof required')
    for number in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(number,stop_signal)
    need(packet.is_relative_to('/dev/shm'),'stage the source packet on ordinary host /dev/shm')
    need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==args.expected_boot_id,'fresh parent boot reconciliation required')
    packet_verify(packet,args.packet_manifest_sha256)
    for path in sorted(packet.rglob('*.py')):compile(path.read_bytes(),str(path),'exec')
    mount=[line.split() for line in Path('/proc/self/mountinfo').read_text().splitlines() if line.split()[4]=='/dev/shm']
    need(len(mount)==1 and 'noexec' not in mount[0][5].split(','),'ordinary host tmpfs must allow native execution')
    parent_row=inspect(args.parent_id)
    need(parent_row['Id']==args.parent_id and parent_row['State']['Running'] and parent_row['Image']==IMAGE,
         'reconcile exact existing parent and pinned cached image first')
    need(parent_row['HostConfig']['Memory']==MEMORY and parent_row['HostConfig']['MemorySwap']==MEMORY,
         'existing parent must have64GiB/zero-swap configuration')
    image=json.loads(rpc(['docker','image','inspect',IMAGE]).stdout)[0]
    need(not image['Config'].get('Volumes'),'unreviewed implicit image volumes would escape owned staging')
    parent={'id':parent_row['Id'],'pid':parent_row['State']['Pid'],
            'birth':birth(parent_row['State']['Pid']),'image':parent_row['Image']}
    root=Path('/dev/shm')/('sdk01-portable-compile-r652-'+args.mode+'-'+uuid.uuid4().hex)
    root.mkdir(mode=0o700)
    lease=Path('/home/macromodel/Documents/uwvm2-ros-test/control/test.lock')
    need(lease.is_file() and not lease.is_symlink(),'canonical existing lease inode is absent; do not invent another lock')
    info=lease.stat()
    need((info.st_dev,info.st_ino,info.st_uid,info.st_gid,info.st_mode & 0o7777)==(66312,17575649,1000,1000,0o664),'current canonical lease identity differs')
    need(parent_row['HostConfig']['CgroupParent']=='uwvmros.slice','new shared anchor required')
    host_membership(parent['pid'])
    summary={'passed':False,'status':'SOURCE_PACKET_ACTUAL_RUN_STARTED','mode':args.mode,
             'packet_manifest_sha256':args.packet_manifest_sha256,'boot_id':args.expected_boot_id,
             'parent':parent,'cases':[],'started_ns':time.monotonic_ns(),'control_envelope':control_admission,
             'control_source_manifest_sha256':envelope['source_manifest_sha256'],
             'control_admission_path':os.environ['UWVM_CONTROL_ADMISSION'],'control_records_path':os.environ['UWVM_CONTROL_RECORDS']}
    active=[]
    if args.mode=='qualify':
        proof_validate(args.guardian_proof,args.guardian_proof_sha256,args.packet_manifest_sha256,args.expected_boot_id,parent)

    def start_batch(label):
        need(not STOP,'request interrupted before another owned batch')
        nonce=uuid.uuid4().hex;directory=root/label;directory.mkdir(mode=0o700);(directory/'work').mkdir(mode=0o700)
        context={'nonce':nonce,'mode':label,
                 'context':str(directory),'packet':str(packet),'packet_manifest_sha256':args.packet_manifest_sha256,
                 'boot_id':args.expected_boot_id,'parent':parent,'lease':str(lease),
                 'canonical_lease_device_inode':device_key(info),'control_envelope':control_guard('requester-context'),
                 'parent_config':{key:parent_row['HostConfig'].get(key) for key in ('Memory','MemorySwap','CpusetCpus','Privileged','ReadonlyRootfs','NetworkMode','CgroupParent')},
                 'host_root_device':os.stat('/').st_dev,
                 'requester':{'pid':os.getpid(),'birth':birth(os.getpid())},'uid':os.getuid(),'gid':os.getgid(),
                 'container_name':'uwsdk01-portable-compile-r652-'+nonce,
                 'accepted15_receipt_sha256':args.accepted15_receipt_sha256,
                 'host_budget_bytes':INPUT_CAP+OUTPUT_CAP+CONTROL_CAP}
        save(directory/'context.json',context)
        read_end,write_end=os.pipe()
        with (directory/'controller.stdout').open('wb') as output,(directory/'controller.stderr').open('wb') as error:
            controller=subprocess.Popen([sys.executable,'-B',str(packet/'keeper.py'),'--context',str(directory/'context.json'),
                    '--requester-watch-fd',str(read_end)],pass_fds=(read_end,),stdin=subprocess.DEVNULL,
                    stdout=output,stderr=error,start_new_session=True)
        os.close(read_end)
        state={'directory':directory,'controller':controller,'birth':birth(controller.pid),'write_end':write_end}
        active.append(state)
        def ready():
            need(controller.poll() is None,'owned controller failed before ready; inspect '+str(directory))
            path=directory/'guardian.json'
            if not path.exists():return None
            value=json.loads(path.read_text())
            need(value['status'] not in ('RETIRED','QUARANTINED_LEASE_HELD'),'owned guardian admission failed/quarantined')
            return value if value['status']=='RUNNING' else None
        wait_for(ready,180,'lease/fresh sibling admission deadline')
        context=json.loads((directory/'context.json').read_text())
        state.update(context=context,owned=json.loads((directory/'owned-container.json').read_text()))
        return state

    def attempt(directory,label):
        result=rpc([sys.executable,'-B',packet/'try_lease.py','--lease',lease])
        path=directory/(label+'.json');path.write_bytes(result.stdout)
        return json.loads(result.stdout)

    try:
        if args.mode=='prove-guardian':
            sentinel_nonce=uuid.uuid4().hex
            sentinel=subprocess.Popen([sys.executable,'-B',str(packet/'proof_sentinel.py'),'--nonce',sentinel_nonce],
                    stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
            sentinel_birth=birth(sentinel.pid)
            try:
                for name in ('host-controller-loss','inside-controller-loss'):
                    state=start_batch('proof-'+name);directory=state['directory'];context=state['context'];cid=state['owned']['container_id']
                    worker=directory/'work/proof/worker.json'
                    wait_for(lambda:worker.exists(),30,'synthetic worker readiness deadline')
                    before=original_parent(context)
                    sentinel_before={'pid':sentinel.pid,'birth':sentinel_birth,'nonce':sentinel_nonce}
                    need(alive(sentinel.pid,sentinel_birth),'unrelated sentinel absent/reused')
                    owner_proof=host_lease_proof(context)
                    before_attempt=attempt(directory,'lock-before-loss');need(not before_attempt['acquired'],'canonical lease was not held before interruption')
                    if name=='host-controller-loss':
                        controller=state['controller']
                        need(alive(controller.pid,state['birth']),'throwaway controller PID reused')
                        argv=Path(f'/proc/{controller.pid}/cmdline').read_bytes().split(b'\0')
                        need(str(directory/'context.json').encode() in argv,'throwaway controller context/nonce differs')
                        signal_owned(controller.pid,state['birth'],signal.SIGKILL);controller.wait(timeout=10)
                    else:
                        killed=rpc(['docker','exec',cid,'python3','-B','/packet/proof_worker.py','--kill-owner','--nonce',context['nonce']])
                        (directory/'kill-inside.stdout').write_bytes(killed.stdout)
                    def barrier():
                        value=json.loads((directory/'guardian.json').read_text())
                        need(value['status']!='RETIRED','retirement barrier was missed; no proof pass')
                        return value if value['status']=='PROOF_RETIREMENT_BARRIER' else None
                    guardian=wait_for(barrier,30,'guardian did not independently detect the interruption')
                    # After controller death Yama can revoke our procfs FD
                    # access to the reparented guardian. Preserve its actual
                    # self-read and independently test this same inode's lock.
                    fd_observation=guardian['lease_at_proof_barrier']
                    need(fd_observation['pid']==guardian['pid'] and fd_observation['guardian_birth']==guardian['birth']
                         and fd_observation['lease_fd']==guardian['lease_fd'],'guardian FD observation identity differs')
                    held_fd=fd_observation['fdinfo']
                    need('FLOCK' in held_fd and 'WRITE' in held_fd,'guardian inherited lease FD not held after loss')
                    need(alive(guardian['pid'],guardian['birth']),'guardian birth changed')
                    held_inode=fd_observation['device_inode']
                    need(held_inode==context['lease_owner']['device_inode'],'guardian FD inode differs after controller loss')
                    after_loss=attempt(directory,'lock-after-loss');need(not after_loss['acquired'],'lease escaped before child retirement')
                    child=exact_owned(inspect(cid),context);need(child['State']['Running'],'no still-live owned namespace at competing attempt')
                    descendant=rpc(['docker','exec',cid,'python3','-B','/packet/proof_worker.py','--inspect-owner','--nonce',context['nonce']])
                    (directory/'worker-after-loss.stdout').write_bytes(descendant.stdout)
                    worker_after=json.loads(descendant.stdout);need(worker_after['leaf_alive'],'proof did not retain a real descendant')
                    release_ns=time.monotonic_ns()
                    save(directory/'proof-release.json',{'nonce':context['nonce'],'packet_manifest_sha256':args.packet_manifest_sha256,
                         'after_loss_attempt_sha256':sha(directory/'lock-after-loss.json'),'release_ns':release_ns})
                    retired=wait_for(lambda:json.loads((directory/'guardian.json').read_text()) if
                         json.loads((directory/'guardian.json').read_text()).get('retired') else None,90,'owned namespace retirement deadline')
                    wait_for(lambda:not alive(retired['pid'],retired['birth']),30,'guardian did not close after verified retirement')
                    state['controller'].wait(timeout=30)
                    os.close(state['write_end']);state['write_end']=-1
                    after_attempt=attempt(directory,'lock-after-retirement');need(after_attempt['acquired'],'lease unavailable after full retirement/controller exit')
                    need(inspect(cid,absent=True) is None,'owned container remains')
                    after=original_parent(context);need(before==after,'existing parent changed')
                    need(alive(sentinel.pid,sentinel_birth),'unrelated sentinel was affected')
                    synthetic={'worker':json.loads(worker.read_text()),'leaf':json.loads((directory/'work/proof/leaf.json').read_text())}
                    row={'case':name,'passed':True,'nonce':context['nonce'],'container_id':cid,
                         'before_owner_proof':owner_proof,'before_attempt':before_attempt,'after_loss_attempt':after_loss,
                         'after_retirement_attempt':after_attempt,'inherited_fd_after_loss':held_fd,
                         'guardian_fd_device_inode':held_inode,'lease_device_inode':context['lease_owner']['device_inode'],
                         'guardian_fd_self_observation_after_loss':fd_observation,
                         'child_still_running_after_loss':child['State']['Running'],'worker_after_loss':worker_after,
                         'release_ns':release_ns,'guardian':retired,'container_absent':True,'parent_before':before,'parent_after':after,
                         'sentinel_before':sentinel_before,'sentinel_after':dict(sentinel_before),'synthetic':synthetic,'raw_files':[]}
                    need(after_loss['observed_ns']<release_ns<retired['retired_ns']<=after_attempt['observed_ns'],'proof timestamps invalid')
                    for path in sorted(directory.rglob('*')):
                        if path.is_file():row['raw_files'].append({'path':str(path.relative_to(directory)),'sha256':sha(path)})
                    save(directory/'case.json',row)
                    summary['cases'].append({'case':name,'path':str((directory/'case.json').relative_to(root)),
                                             'sha256':sha(directory/'case.json')})
            finally:
                if alive(sentinel.pid,sentinel_birth):signal_owned(sentinel.pid,sentinel_birth,signal.SIGTERM);sentinel.wait(timeout=10)
            summary.update(passed=True,status='PASS_GUARDIAN_ONLY',finished_ns=time.monotonic_ns(),
                           scope='two harmless interruption/lease tests; no product build/test/source acceptance')
            save(root/'proof.json',summary)
            proof_validate(root/'proof.json',sha(root/'proof.json'),args.packet_manifest_sha256,args.expected_boot_id,parent)
            print(json.dumps({'status':summary['status'],'proof':str(root/'proof.json'),'sha256':sha(root/'proof.json')}))
        else:
            state=start_batch('compile-portable');directory=state['directory']
            wait_for(lambda:state['controller'].poll() is not None,720,'finite compiler controller deadline')
            report=json.loads((directory/'keeper.json').read_text())
            need(state['controller'].returncode==0 and report.get('passed') and report['retirement']['retired'], 'compiler failed or retirement incomplete')
            os.close(state['write_end']);state['write_end']=-1
            result=directory/'work/compile/result.json'
            value=json.loads(result.read_text());need(value['status']=='PASS_COMPILED_WASM_STRUCTURE_ONLY','no compiled structural result')
            summary.update(passed=True,status='PASS_COMPILED_WASM_STRUCTURE_ONLY',result_path=str(result),result_sha256=sha(result),
                wasm_sha256=value['wasm_sha256'],finished_ns=time.monotonic_ns(),scope='one emitted fixture only; no VM/ROS/simulator execution')
            save(root/'compile.json',summary)
            print(json.dumps({'status':summary['status'],'root':str(root),'result':str(result),'sha256':sha(result),'wasm_sha256':value['wasm_sha256']}))
    except BaseException as error:
        summary.update(passed=False,status='FAIL_OR_BLOCKED',error=repr(error))
        save(root/'failure.json',summary)
        if (root/'proof.json').exists():save(root/'proof.json',summary)
        raise
    finally:
        # Pipe close survives abrupt requester death through kernel EOF too.
        # The independent guardian retains the inherited flock until retirement.
        for state in active:
            if state['write_end']!=-1:os.close(state['write_end']);state['write_end']=-1
        summary['finished_ns']=time.monotonic_ns();save(root/'requester.json',summary)


if __name__=='__main__':main()
